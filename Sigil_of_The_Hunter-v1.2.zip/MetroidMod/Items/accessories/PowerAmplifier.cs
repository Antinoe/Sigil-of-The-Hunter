using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;
using MetroidMod.Items.damageclass;

namespace MetroidMod.Items.accessories
{
	public class PowerAmplifier : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Sigil of The Hunter");
			Tooltip.SetDefault("Multiplies the user's strength and fortitude, but drastically increases the overheat of their Arm Cannon.\n" + 
			"Multiplies Defense by 100%.\n" + "Multiplies Hunter Damage by 150%.\n" + "Multiplies Overheating by 50%.\n" + "Multiplies Hunter Crit by 25%.\n");
		}
		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 20;
			item.maxStack = 1;
			item.value = 10000;
			item.rare = 6;
			item.accessory = true;
		}
		public override void UpdateAccessory(Player player, bool hideVisual)
		{
			MPlayer mp = player.GetModPlayer<MPlayer>();
			//mp.maxOverheat += 30;
			mp.overheatCost += 0.50f;
			HunterDamagePlayer.ModPlayer(player).hunterDamageMult += 1.50f;
			HunterDamagePlayer.ModPlayer(player).hunterCrit += 25;
			player.statDefense = (int)(player.statDefense * 2f);
        }
		
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.LunarBar, 4);
            recipe.AddIngredient(ItemID.Amethyst, 1);
            recipe.AddIngredient(ItemID.Topaz, 1);
            recipe.AddIngredient(ItemID.Sapphire, 1);
            recipe.AddIngredient(ItemID.Emerald, 1);
            recipe.AddIngredient(ItemID.Ruby, 1);
            recipe.AddIngredient(ItemID.Diamond, 1);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
